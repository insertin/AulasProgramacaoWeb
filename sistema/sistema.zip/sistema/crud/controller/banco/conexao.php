<?php

$conexao = new mysqli('localhost', 'root', '', 'crud') or die(mysqli_error($conexao));

