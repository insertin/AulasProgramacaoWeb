<!DOCTYPE html>
<html>

<head>
    <?php
    require_once('view/head.php');
    ?>
</head>

<body>
    <?php require_once('view/nav.php'); ?>

</body>

</html>